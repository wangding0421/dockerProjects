package conformance.rmi;

import rmi.RMIException;

class SimpleServer implements SimpleInterface
{
    @Override
    public void testMethod() throws RMIException
    {
    }
}
